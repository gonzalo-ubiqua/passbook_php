<?php
$tabla_cuentas = array (
	'ubiquadev'		    => array(
		'nombre_emisor'	=> "Cortijo Fontanilla",
    'emisor' => 'ubiqua.developer@gmail.com',
    'host' => 'smtp.gmail.com',
    'port' => 587,
    'auth' => 'true',
    'username' => 'ubiqua.developer@gmail.com',
    'password' => '20Ubiq2015',
    'localhost' => 'gmail.com'
  ),
	'ubiquagon'		    => array(
		'nombre_emisor'	=> "Ubiqua developer",
    'emisor' => 'gonzalo@ubiqua.es',
    'host' => 'mail.ubiqua.es',
    'port' => 465,
    'auth' => 'true',
    'username' => 'gonzalo@ubiqua.es',
    'password' => 'Txoff678?',
    'localhost' => 'ubiqua.es'
  ),
	'petrasoft'		    => array(
		'nombre_emisor'	=> "Gonzalo",
    'emisor' => 'gonzalo@petrasoft.es',
    'host' => 'www.petrasoft.es',
    'port' => 25, // 465,
    'auth' => 'true',
    'username' => 'gonzalo@petrasoft.es',
    'password' => 'W?26myN4Sc(.',
    'localhost' => 'petrasoft.es'
  ),
	'gonzalo1k'		    => array(
		'nombre_emisor'	=> "Cortijo Fontanilla",
    'emisor' => 'gonzalo1k@gmail.com',
    'host' => 'smtp.gmail.com',
    'port' => 587,
    'auth' => 'true',
    'username' => 'gonzalo1k@gmail.com',
    'password' => 'txoff6',
    'localhost' => 'gmail.com'
  )
);
// $mail->SMTPSecure = 'tls';
$cuenta = 'ubiquadev';

?>
